Add icon16.png (16x16), icon48.png (48x48), icon128.png (128x128) here.
Green GST-themed icons recommended.